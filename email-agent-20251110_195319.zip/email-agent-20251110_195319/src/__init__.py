"""Email Agent - AI-powered email management system."""

__version__ = "1.0.0"
__author__ = "Email Agent Team"
__description__ = "AI-powered email management with Google Gemini and ADK"
