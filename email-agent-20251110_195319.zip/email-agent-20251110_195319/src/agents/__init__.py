"""Agents module."""

from .email_agent import EmailAgent

__all__ = ["EmailAgent"]
