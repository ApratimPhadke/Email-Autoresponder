"""MCP (Model Context Protocol) module."""

from .smtp_server import MCPSMTPServer

__all__ = ["MCPSMTPServer"]
